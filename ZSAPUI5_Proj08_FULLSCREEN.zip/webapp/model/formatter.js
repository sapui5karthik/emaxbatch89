sap.ui.define([
	] , function () {
		"use strict";

		return {
	

			width1 : function(w1){
				if(!w1){ return ""; }
			return 	parseFloat(w1).toFixed(0);
			},
			disc1  :function(disc2){
				if(disc2 >= 1000 && disc2 <= 2000){
					return disc2 - 500;
				}
				if(disc2 >= 2000){
					return disc2 - 1000;
				}
				
				return disc2;
				
			},
			date1 : function(d1){
				var d2 = new Date(d1);
				if(d2 !== undefined){
					var d3 = sap.ui.core.format.DateFormat.getInstance({
						pattern : 'MMM/dd/yyyy'
					});
					var d4 = d3.format(d2);
					return d4;
				}
				else return "";
			},
			
			date2 : function(d2){
				if(d2 !== undefined){
					var d3 = new Date(d2);
					 var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
					return d3.toLocaleDateString("ta",options);
				}
			},
			/**
			 * Rounds the number unit value to 2 digits
			 * @public
			 * @param {string} sValue the number string to be rounded
			 * @returns {string} sValue with 2 digits rounded
			 */
			numberUnit : function (sValue) {
				if (!sValue) {
					return "";
				}
				return parseFloat(sValue).toFixed(2);
			}

		};

	}
);