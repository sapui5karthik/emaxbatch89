sap.ui.define([
	] , function () {
		"use strict";

		return {
	

			width1 : function(w1){
				
				
			return 	parseFloat(w1).toFixed(0);
			},
			disc1  :function(disc2){
				if(disc2 >= 1000 && disc2 <= 2000){
					return disc2 - 500;
				}
				if(disc2 >= 2000){
					return disc2 - 1000;
				}
				
				return disc2;
				
			},

			/**
			 * Rounds the number unit value to 2 digits
			 * @public
			 * @param {string} sValue the number string to be rounded
			 * @returns {string} sValue with 2 digits rounded
			 */
			numberUnit : function (sValue) {
				if (!sValue) {
					return "";
				}
				return parseFloat(sValue).toFixed(2);
			}

		};

	}
);