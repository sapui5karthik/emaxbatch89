jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
		"sap/ui/test/Opa5",
		"zsapui5proj08/test/integration/pages/Common",
		"sap/ui/test/opaQunit",
		"zsapui5proj08/test/integration/pages/Worklist",
		"zsapui5proj08/test/integration/pages/Object",
		"zsapui5proj08/test/integration/pages/NotFound",
		"zsapui5proj08/test/integration/pages/Browser",
		"zsapui5proj08/test/integration/pages/App"
	], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "zsapui5proj08.view."
	});

	sap.ui.require([
		"zsapui5proj08/test/integration/WorklistJourney",
		"zsapui5proj08/test/integration/ObjectJourney",
		"zsapui5proj08/test/integration/NavigationJourney",
		"zsapui5proj08/test/integration/NotFoundJourney",
		"zsapui5proj08/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});