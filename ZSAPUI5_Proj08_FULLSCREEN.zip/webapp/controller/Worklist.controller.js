sap.ui.define([
	"zsapui5proj08/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/odata/ODataModel",
	"sap/ui/core/routing/History",
	"zsapui5proj08/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageToast"
], function(BaseController, JSONModel, ODataModel, History, formatter, Filter, FilterOperator, MessageToast) {
	"use strict";

	return BaseController.extend("zsapui5proj08.controller.Worklist", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		onInit: function() {

			var data_sapservice = "/sap/opu/odata/iwbep/GWSAMPLE_BASIC/";
			var odatamodel_sapprod = new ODataModel(data_sapservice);
			var jsonmodel_sapprod = new JSONModel();

			var otable = this.byId("tablesapprod");
			otable.setBusy(true);
			odatamodel_sapprod.read("/ProductSet", {
				success: function(odata, resp) {
					jsonmodel_sapprod.setSizeLimit(1000);
					jsonmodel_sapprod.setData(odata.results);
					this.getView().byId("tablesapprod").setModel(jsonmodel_sapprod, "sapprod");
					this.getView().byId("idcombdyna").setModel(jsonmodel_sapprod, "sapprodcomb");
					otable.setBusy(false);
				}.bind(this),
				error: function(msg) {
					MessageToast.show("Failed:1000" + msg);
					otable.setBusy(false);
				}
			});

		}, // end of onInit
		_refresh: function() {
			this.onInit();
		}, // end of _refresh
		_orderbyprice: function() {
			var data_sapservice = "/sap/opu/odata/iwbep/GWSAMPLE_BASIC/";
			var odatamodel_sapprod = new ODataModel(data_sapservice);
			var jsonmodel_sapprod = new JSONModel();
			var otable = this.byId("tablesapprod");
			otable.setBusy(true);
			odatamodel_sapprod.read("/ProductSet?$orderby=Price", {
				success: function(odata, resp) {
					jsonmodel_sapprod.setData(odata.results);
					this.getView().byId("tablesapprod").setModel(jsonmodel_sapprod, "sapprod");
					otable.setBusy(false);
				}.bind(this),
				error: function(msg) {
					MessageToast.show("Failed:" + msg);
					otable.setBusy(false);
				}
			});

		}, // end of _orderby
		_orderbycat: function() {
			var data_sapservice = "/sap/opu/odata/iwbep/GWSAMPLE_BASIC/";
			var odatamodel_sapprod = new ODataModel(data_sapservice);
			var jsonmodel_sapprod = new JSONModel();
			var otable = this.byId("tablesapprod");
			otable.setBusy(true);
			odatamodel_sapprod.read("/ProductSet?$orderby=Category", {
				success: function(odata, resp) {
					jsonmodel_sapprod.setData(odata.results);
					this.getView().byId("tablesapprod").setModel(jsonmodel_sapprod, "sapprod");
					otable.setBusy(false);
				}.bind(this),
				error: function(msg) {
					MessageToast.show("Failed:" + msg);
					otable.setBusy(false);
				}
			});
		}, // end of _orderbycat
		_pricelt5: function() {
			var data_sapservice = "/sap/opu/odata/iwbep/GWSAMPLE_BASIC/";
			var odatamodel_sapprod = new ODataModel(data_sapservice);
			var jsonmodel_sapprod = new JSONModel();
			var filter1 = new Filter("Price", FilterOperator.LT, 5);

			var otable = this.byId("tablesapprod");
			otable.setBusy(true);
			odatamodel_sapprod.read("/ProductSet", {
				filters: [filter1],
				success: function(odata, resp) {
					jsonmodel_sapprod.setData(odata.results);
					this.getView().byId("tablesapprod").setModel(jsonmodel_sapprod, "sapprod");
					otable.setBusy(false);
				}.bind(this),
				error: function(msg) {
					MessageToast.show("Failed:" + msg);
					otable.setBusy(false);
				}
			});
		}, // end of _pricelt5
		_catnotebook: function() {
var data_sapservice = "/sap/opu/odata/iwbep/GWSAMPLE_BASIC/";
			var odatamodel_sapprod = new ODataModel(data_sapservice);
			var jsonmodel_sapprod = new JSONModel();
			var filter1 = new Filter("Category", FilterOperator.EQ,"Notebooks");
			

			var otable = this.byId("tablesapprod");
			otable.setBusy(true);
			odatamodel_sapprod.read("/ProductSet", {
				filters: [filter1],
				success: function(odata, resp) {
					jsonmodel_sapprod.setData(odata.results);
					this.getView().byId("tablesapprod").setModel(jsonmodel_sapprod, "sapprod");
					otable.setBusy(false);
				}.bind(this),
				error: function(msg) {
					MessageToast.show("Failed:" + msg);
					otable.setBusy(false);
				}
			});
		}, // end of _catnotebook

		_catnotebookbelow1000 : function(){
			var data_sapservice = "/sap/opu/odata/iwbep/GWSAMPLE_BASIC/";
				var odatamodel_sapprod = new ODataModel(data_sapservice);
			var jsonmodel_sapprod = new JSONModel();
			var filter1 = new Filter("Category", FilterOperator.EQ,"Notebooks");
			var filter2 = new Filter("Price", FilterOperator.LT, 1000);
			
			var otable = this.byId("tablesapprod");
			otable.setBusy(true);
			odatamodel_sapprod.read("/ProductSet", {
				filters: [filter1,filter2],
				success: function(odata, resp) {
					jsonmodel_sapprod.setData(odata.results);
					this.getView().byId("tablesapprod").setModel(jsonmodel_sapprod, "sapprod");
					otable.setBusy(false);
				}.bind(this),
				error: function(msg) {
					MessageToast.show("Failed:" + msg);
					otable.setBusy(false);
				}
			});
		}, // end of _catnotebookbelow1000
		_catsearch : function(){
			
			//var catsearch = this.byId("idcatsearch").mProperties.value;
			var catsearch = this.byId("idcatsearch").getValue();
			var data_sapservice = "/sap/opu/odata/iwbep/GWSAMPLE_BASIC/";
			var odatamodel_sapprod = new ODataModel(data_sapservice);
			var jsonmodel_sapprod = new JSONModel();
			var filter1 = new Filter("Category", FilterOperator.Contains,catsearch);
			

			var otable = this.byId("tablesapprod");
			otable.setBusy(true);
			odatamodel_sapprod.read("/ProductSet", {
				filters: [filter1],
				success: function(odata, resp) {
					jsonmodel_sapprod.setData(odata.results);
					this.getView().byId("tablesapprod").setModel(jsonmodel_sapprod, "sapprod");
					otable.setBusy(false);
				}.bind(this),
				error: function(msg) {
					MessageToast.show("Failed:" + msg);
					otable.setBusy(false);
				}
			});
			
		}, // end of _catsearch
		_combostatic : function(){
			var keys = this.byId("idcombstatic").getSelectedKey();
			if(keys===0){
				this.onInit();
			}
			if(keys==="1"){
				this._orderbyprice();
			}
			if(keys==="2"){
				this._pricelt5();
			}
			if(keys==="3"){
				this._catnotebook();                                                               
			}
			if(keys==="4"){
				this._catnotebookbelow1000();                                
			}
			if(keys==="5"){
				this._orderbycat();
			}
		}, // end of _combostatic
		_combodyna : function(oevent){
			
			var text = oevent.getParameter("value");
			
			var data_sapservice = "/sap/opu/odata/iwbep/GWSAMPLE_BASIC/";
			var odatamodel_sapprod = new ODataModel(data_sapservice);
			var jsonmodel_sapprod = new JSONModel();
			var filter1 = new Filter("ProductID", FilterOperator.Contains,text);
			

			var otable = this.byId("tablesapprod");
			otable.setBusy(true);
			odatamodel_sapprod.read("/ProductSet", {
				filters: [filter1],
				success: function(odata, resp) {
					jsonmodel_sapprod.setData(odata.results);
					this.getView().byId("tablesapprod").setModel(jsonmodel_sapprod, "sapprod");
					otable.setBusy(false);
				}.bind(this),
				error: function(msg) {
					MessageToast.show("Failed:" + msg);
					otable.setBusy(false);
				}
			});
		
		}, // end of _combodyna
		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		_onInit: function() {
			var oViewModel,
				iOriginalBusyDelay,
				oTable = this.byId("table");

			// Put down worklist table's original value for busy indicator delay,
			// so it can be restored later on. Busy handling on the table is
			// taken care of by the table itself.
			iOriginalBusyDelay = oTable.getBusyIndicatorDelay();
			this._oTable = oTable;
			// keeps the search state
			this._oTableSearchState = [];

			// Model used to manipulate control states
			oViewModel = new JSONModel({
				worklistTableTitle: this.getResourceBundle().getText("worklistTableTitle"),
				saveAsTileTitle: this.getResourceBundle().getText("saveAsTileTitle", this.getResourceBundle().getText("worklistViewTitle")),
				shareOnJamTitle: this.getResourceBundle().getText("worklistTitle"),
				shareSendEmailSubject: this.getResourceBundle().getText("shareSendEmailWorklistSubject"),
				shareSendEmailMessage: this.getResourceBundle().getText("shareSendEmailWorklistMessage", [location.href]),
				tableNoDataText: this.getResourceBundle().getText("tableNoDataText"),
				tableBusyDelay: 0
			});
			this.setModel(oViewModel, "worklistView");

			// Make sure, busy indication is showing immediately so there is no
			// break after the busy indication for loading the view's meta data is
			// ended (see promise 'oWhenMetadataIsLoaded' in AppController)
			oTable.attachEventOnce("updateFinished", function() {
				// Restore original busy indicator delay for worklist's table
				oViewModel.setProperty("/tableBusyDelay", iOriginalBusyDelay);
			});
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Triggered by the table's 'updateFinished' event: after new table
		 * data is available, this handler method updates the table counter.
		 * This should only happen if the update was successful, which is
		 * why this handler is attached to 'updateFinished' and not to the
		 * table's list binding's 'dataReceived' method.
		 * @param {sap.ui.base.Event} oEvent the update finished event
		 * @public
		 */
		onUpdateFinished: function(oEvent) {
			// update the worklist's object counter after the table update
			var sTitle,
				oTable = oEvent.getSource(),
				iTotalItems = oEvent.getParameter("total");
			// only update the counter if the length is final and
			// the table is not empty
			if (iTotalItems && oTable.getBinding("items").isLengthFinal()) {
				sTitle = this.getResourceBundle().getText("worklistTableTitleCount", [iTotalItems]);
			} else {
				sTitle = this.getResourceBundle().getText("worklistTableTitle");
			}
			this.getModel("worklistView").setProperty("/worklistTableTitle", sTitle);
		},

		/**
		 * Event handler when a table item gets pressed
		 * @param {sap.ui.base.Event} oEvent the table selectionChange event
		 * @public
		 */
		onPress: function(oEvent) {
			// The source is the list item that got pressed
			this._showObject(oEvent.getSource());
		},

		/**
		 * Event handler when the share in JAM button has been clicked
		 * @public
		 */
		onShareInJamPress: function() {
			var oViewModel = this.getModel("worklistView"),
				oShareDialog = sap.ui.getCore().createComponent({
					name: "sap.collaboration.components.fiori.sharing.dialog",
					settings: {
						object: {
							id: location.href,
							share: oViewModel.getProperty("/shareOnJamTitle")
						}
					}
				});
			oShareDialog.open();
		},

		onSearch: function(oEvent) {
			if (oEvent.getParameters().refreshButtonPressed) {
				// Search field's 'refresh' button has been pressed.
				// This is visible if you select any master list item.
				// In this case no new search is triggered, we only
				// refresh the list binding.
				this.onRefresh();
			} else {
				var oTableSearchState = [];
				var sQuery = oEvent.getParameter("query");

				if (sQuery && sQuery.length > 0) {
					oTableSearchState = [new Filter("SupplierName", FilterOperator.Contains, sQuery)];
				}
				this._applySearch(oTableSearchState);
			}

		},

		/**
		 * Event handler for refresh event. Keeps filter, sort
		 * and group settings and refreshes the list binding.
		 * @public
		 */
		onRefresh: function() {
			this._oTable.getBinding("items").refresh();
		},

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/**
		 * Shows the selected item on the object page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 * @private
		 */
		_showObject: function(oItem) {
			this.getRouter().navTo("object", {
				objectId: oItem.getBindingContext().getProperty("ProductID")
			});
		},

		/**
		 * Internal helper method to apply both filter and search state together on the list binding
		 * @param {object} oTableSearchState an array of filters for the search
		 * @private
		 */
		_applySearch: function(oTableSearchState) {
			var oViewModel = this.getModel("worklistView");
			this._oTable.getBinding("items").filter(oTableSearchState, "Application");
			// changes the noDataText of the list in case there are no filter results
			if (oTableSearchState.length !== 0) {
				oViewModel.setProperty("/tableNoDataText", this.getResourceBundle().getText("worklistNoDataWithSearchText"));
			}
		}

	});
});