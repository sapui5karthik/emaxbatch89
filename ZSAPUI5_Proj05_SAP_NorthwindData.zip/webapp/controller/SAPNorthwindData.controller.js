sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("ZSAPUI5_Proj05_SAP_NorthwindDataZSAPUI5_Proj05_SAP_NorthwindData.controller.SAPNorthwindData", {

		onInit: function() {

			/*// SAP ProductSet
			var sapdata = "/sap/opu/odata/iwbep/GWSAMPLE_BASIC/";
			var odatamodel_sap = new sap.ui.model.odata.ODataModel(sapdata);
			var jsonmodel_sap = new sap.ui.model.json.JSONModel();
			var otablesap = this.byId("table1");
			otablesap.setBusy(true);

			odatamodel_sap.read("/ProductSet", {
				success: function(request, response) {

					jsonmodel_sap.setSizeLimit(1000);
					jsonmodel_sap.setData(request.results);
					this.getView().byId("table1").setModel(jsonmodel_sap, "sapprod");
					otablesap.setBusy(false);
				}.bind(this),
				error: function(msg) {
					otablesap.setBusy(false);
					sap.m.MessageToast.show("Failed:Retry again" + msg);
				}
			}); */// end of odatamodel_sap

		// Northwind Products Data
		var data_nw = "/northwind/V2/Northwind/Northwind.svc/";
		
		var odatamodel_nw = new sap.ui.model.odata.ODataModel(data_nw);
		var jsonmodel_nw = new sap.ui.model.json.JSONModel();
		var otable_nw = this.byId("table2");
		otable_nw.setBusy(true);
		odatamodel_nw.read("/Products",{
			success : function(req,res){ 
				jsonmodel_nw.setSizeLimit(1000);
				jsonmodel_nw.setData(req.results);
				this.getView().byId("table2").setModel(jsonmodel_nw,"nwp");
				this.getView().byId("combodynamic").setModel(jsonmodel_nw,"cbp");
				otable_nw.setBusy(false);
			}.bind(this),
			error : function(msg){
				sap.m.MessageToast.show("Failed:Retry again" + msg);
				otable_nw.setBusy(false);
			}
		});


			// SAP SalesorderSet Data
		/*var data_sapsales = "/sap/opu/odata/iwbep/GWSAMPLE_BASIC/";
		
		var odatamodel_sapsales = new sap.ui.model.odata.ODataModel(data_sapsales);
		var jsonmodel_sapsales = new sap.ui.model.json.JSONModel();
		
		odatamodel_sapsales.read("/SalesOrderSet",{
			success : function(odata,resp){
				
				jsonmodel_sapsales.setData(odata.results);
				this.getView().byId("table3").setModel(jsonmodel_sapsales,"sapsales");
				
			}.bind(this),
			error : function(msg){
				sap.m.MessageToast.show("Failed:" + msg);
			}
			
			
		});*/

		// SAP BusinessPartnerSet
		
		// Northwind Customers
		




		}, // end of onInit
		
		_orderbyprice: function(){ 
				var data_nw = "/northwind/V2/Northwind/Northwind.svc/";
		
		var odatamodel_nw = new sap.ui.model.odata.ODataModel(data_nw);
		var jsonmodel_nw = new sap.ui.model.json.JSONModel();
		var otable_nw = this.byId("table2");
		otable_nw.setBusy(true);
		odatamodel_nw.read("/Products?$orderby=UnitPrice",{
			success : function(req,res){ 
				jsonmodel_nw.setSizeLimit(1000);
				jsonmodel_nw.setData(req.results);
				this.getView().byId("table2").setModel(jsonmodel_nw,"nwp");
				otable_nw.setBusy(false);
			}.bind(this),
			error : function(msg){
				sap.m.MessageToast.show("Failed:Retry again" + msg);
				otable_nw.setBusy(false);
			}
		});
		}, //end of _orderbyprice
		_pricebelow10 : function(){ 
				var data_nw = "/northwind/V2/Northwind/Northwind.svc/";
		
		var odatamodel_nw = new sap.ui.model.odata.ODataModel(data_nw);
		var jsonmodel_nw = new sap.ui.model.json.JSONModel();
		var filter1 = new sap.ui.model.Filter("UnitPrice",sap.ui.model.FilterOperator.LT,10);
		var otable_nw = this.byId("table2");
		otable_nw.setBusy(true);
		odatamodel_nw.read("/Products",{
			filters : [filter1],
			success : function(req,res){ 
				jsonmodel_nw.setSizeLimit(1000);
				jsonmodel_nw.setData(req.results);
				this.getView().byId("table2").setModel(jsonmodel_nw,"nwp");
				otable_nw.setBusy(false);
			}.bind(this),
			error : function(msg){
				sap.m.MessageToast.show("Failed:Retry again" + msg);
				otable_nw.setBusy(false);
			}
		});
		}, //end of __pricebelow10
		_orderbypname : function(){
				var data_nw = "/northwind/V2/Northwind/Northwind.svc/";
		
		var odatamodel_nw = new sap.ui.model.odata.ODataModel(data_nw);
		var jsonmodel_nw = new sap.ui.model.json.JSONModel();
		var otable_nw = this.byId("table2");
		otable_nw.setBusy(true);
		odatamodel_nw.read("/Products?$orderby=ProductName",{
			success : function(req,res){ 
				jsonmodel_nw.setSizeLimit(1000);
				jsonmodel_nw.setData(req.results);
				this.getView().byId("table2").setModel(jsonmodel_nw,"nwp");
				otable_nw.setBusy(false);
			}.bind(this),
			error : function(msg){
				sap.m.MessageToast.show("Failed:Retry again" + msg);
				otable_nw.setBusy(false);
			}
		});}, // end of _orderbypname
		_refresh : function(){ 
			this.onInit();
			
		}, // end of _refresh
		_comboselect : function(){
			//debugger;
			//this.byId("combostatic").mProperties.selectedKey;
			var key = this.byId("combostatic").getSelectedKey();
			//console.log(key);
			if(key === "0"){
				this._refresh();
			}
			if(key === "1"){
				this._orderbyprice();
			}
			if(key === "2"){
				this._pricebelow10();
			}
			if(key === "3"){
				this._orderbypname();
			}
		
			
		}, // end of _comboselect
		_comboseldyn : function(oevent){
		var pname = oevent.getParameter("value");
		var data_nw = "/northwind/V2/Northwind/Northwind.svc/";
			var odatamodel_nw = new sap.ui.model.odata.ODataModel(data_nw);
		var jsonmodel_nw = new sap.ui.model.json.JSONModel();
		var filter1 = new sap.ui.model.Filter("ProductName",sap.ui.model.FilterOperator.EQ,pname);
		var otable_nw = this.byId("table2");
		otable_nw.setBusy(true);
		odatamodel_nw.read("/Products",{
			filters : [filter1],
			success : function(req,res){ 
				jsonmodel_nw.setSizeLimit(1000);
				jsonmodel_nw.setData(req.results);
				this.getView().byId("table2").setModel(jsonmodel_nw,"nwp");
				otable_nw.setBusy(false);
			}.bind(this),
			error : function(msg){
				sap.m.MessageToast.show("Failed:Retry again" + msg);
				otable_nw.setBusy(false);
			}
		});
		}, // end of _comboseldyn
		
	});
});