sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("ZSAPUI5_Proj05_SAP_NorthwindDataZSAPUI5_Proj05_SAP_NorthwindData.controller.SAPNorthwindData", {

		onInit: function() {

			// SAP ProductSet
			var sapdata = "/sap/opu/odata/iwbep/GWSAMPLE_BASIC/";
			var odatamodel_sap = new sap.ui.model.odata.ODataModel(sapdata);
			var jsonmodel_sap = new sap.ui.model.json.JSONModel();
			var otablesap = this.byId("table1");
			otablesap.setBusy(true);

			odatamodel_sap.read("/ProductSet", {
				success: function(request, response) {

					jsonmodel_sap.setSizeLimit(1000);
					jsonmodel_sap.setData(request.results);
					this.getView().byId("table1").setModel(jsonmodel_sap, "sapprod");
					otablesap.setBusy(false);
				}.bind(this),
				error: function(msg) {
					otablesap.setBusy(false);
					sap.m.MessageToast.show("Failed:Retry again" + msg);
				}
			}); // end of odatamodel_sap

		// Northwind Products Data
		var data_nw = "/northwind/V2/Northwind/Northwind.svc/";
		
		var odatamodel_nw = new sap.ui.model.odata.ODataModel(data_nw);
		var jsonmodel_nw = new sap.ui.model.json.JSONModel();
		var otable_nw = this.byId("table2");
		otable_nw.setBusy(true);
		odatamodel_nw.read("/Products",{
			success : function(req,res){ 
				jsonmodel_nw.setSizeLimit(1000);
				jsonmodel_nw.setData(req.results);
				this.getView().byId("table2").setModel(jsonmodel_nw,"nwp");
				otable_nw.setBusy(false);
			}.bind(this),
			error : function(msg){
				sap.m.MessageToast.show("Failed:Retry again" + msg);
				otable_nw.setBusy(false);
			}
		});



		}, // end of onInit
		
		
		
		
		
	});
});